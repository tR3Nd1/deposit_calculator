<?php
	print_r($_SERVER);
	echo $_SERVER['SERVER_ADDR']; 
	phpinfo();
?>
