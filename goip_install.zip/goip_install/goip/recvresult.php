<?php
$postData = file_get_contents('php://input');
echo $postData ;
?>
