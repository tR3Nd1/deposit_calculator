<?php
$white_list[]="#123*!#";
$white_list[]="#123#";
?>
