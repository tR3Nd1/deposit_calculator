<?php
require "excel_class.php";

$return[0][0]="1";
$return[0][1]="2";
$return[1][0]="3";
$return[1][1]="4";
Create_Excel_File("ddd.xls",$return);
?>
